# QuadLoafe Desktop

A borderless XP-style window for QuadLoafe, with its own icon and taskbar entry.

1. Install Node.js (nodejs.org).
2. In this folder run `npm install`, then `npm start`.
3. Optional, Windows app folder with the icon baked in: `npm run pack`.

The title bar is the page's own. Drag it to move the window, drag any edge to resize,
and use its buttons: full screen, minimize, maximize or restore, close.
Double-click the video for full screen; Esc leaves it.
The W key opens the small always-on-top mini player.
