const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('qlDesktop', {
  minimize: () => ipcRenderer.send('win', 'minimize'),
  maximize: () => ipcRenderer.send('win', 'maximize'),
  fullscreen: () => ipcRenderer.send('win', 'fullscreen'),
  close: () => ipcRenderer.send('win', 'close'),
  fetch: (url, opts) => ipcRenderer.invoke('fetch', url, opts),
  onState: (cb) => ipcRenderer.on('state', (_e, s) => cb(s)),
});
