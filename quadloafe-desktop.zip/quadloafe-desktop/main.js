// QuadLoafe Desktop: a borderless window around quadloafe's index.html.
// The page draws its own XP title bar. This file supplies drag, resize, the window
// buttons (minimize, maximize, full screen, close), the taskbar icon, and network
// access for the "YouTube search pages" source (no browser cross-origin limits).
const { app, BrowserWindow, ipcMain, Menu, shell, net } = require('electron');
const path = require('path');

const ICON = path.join(__dirname, process.platform === 'win32' ? 'icon.ico' : 'icon.png');
app.setAppUserModelId('com.quadloafe.app'); // gives Windows its own taskbar entry and icon

if (!app.requestSingleInstanceLock()) app.quit();

let win;
function createWindow() {
  win = new BrowserWindow({
    width: 1100, height: 720, minWidth: 520, minHeight: 360,
    frame: false,            // borderless: the page draws the title bar
    resizable: true,         // resize from the edges
    backgroundColor: '#0831d9',
    icon: ICON, title: 'QuadLoafe', autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false,
      autoplayPolicy: 'no-user-gesture-required',
    },
  });
  Menu.setApplicationMenu(null);
  win.loadFile('index.html');

  const state = () => win.webContents.send('state', { max: win.isMaximized(), full: win.isFullScreen() });
  ['maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen'].forEach((e) => win.on(e, state));
  win.webContents.on('before-input-event', (_e, i) => {
    if (i.type === 'keyDown' && i.key === 'Escape' && win.isFullScreen()) win.setFullScreen(false);
  });
  win.webContents.on('page-title-updated', (e, t) => win.setTitle(t)); // taskbar shows the video title

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url === 'about:blank' || url === '') {   // the mini player
      return { action: 'allow', overrideBrowserWindowOptions: {
        width: 440, height: 300, alwaysOnTop: true, autoHideMenuBar: true,
        icon: ICON, title: 'QuadLoafe mini player', backgroundColor: '#000000' } };
    }
    if (/^https:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
}

ipcMain.on('win', (e, action) => {
  const w = BrowserWindow.fromWebContents(e.sender);
  if (!w) return;
  if (action === 'minimize') w.minimize();
  else if (action === 'maximize') (w.isMaximized() ? w.unmaximize() : w.maximize());
  else if (action === 'fullscreen') w.setFullScreen(!w.isFullScreen());
  else if (action === 'close') w.close();
});

// Network requests for search sources. Only YouTube and Browserless hosts are allowed.
ipcMain.handle('fetch', async (_e, url, o = {}) => {
  const u = new URL(url);
  const ok = u.protocol === 'https:' &&
    (/^(www\.)?youtube\.com$/.test(u.hostname) || /\.browserless\.io$/.test(u.hostname));
  if (!ok) throw new Error('That address isn’t allowed from the desktop app.');
  const method = o.method === 'POST' ? 'POST' : 'GET';
  const r = await net.fetch(url, { method, headers: o.headers, body: method === 'POST' ? o.body : undefined });
  return { ok: r.ok, status: r.status, text: await r.text() };
});

app.whenReady().then(createWindow);
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.on('window-all-closed', () => app.quit());
